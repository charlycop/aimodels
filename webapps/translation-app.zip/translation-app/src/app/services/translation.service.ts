import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {
  private worker: Worker;
  public progressUpdates = new Subject<any>();
  public translationUpdates = new Subject<string>();

  constructor() {
    this.worker = new Worker(new URL('../../assets/worker.js', import.meta.url), { type: 'module' });
    this.worker.onmessage = (event) => {
      if (event.data.status === 'update' || event.data.status === 'complete') {
        this.translationUpdates.next(event.data.output);
      } else {
        this.progressUpdates.next(event.data);
      }
    };
  }

  translate(text: string, sourceLanguage: string, targetLanguage: string) {
    this.worker.postMessage({ text, src_lang: sourceLanguage, tgt_lang: targetLanguage });
  }
}